CREATE TABLE [Type] (
	[type_id] int IDENTITY(1, 1),
	[name] nvarchar(30) NOT NULL,
	PRIMARY KEY ([type_id])
)
GO