CREATE TABLE Goods_type (
	goods_type_id int NOT NULL,
	name nvarchar(30) NOT NULL
	PRIMARY KEY (goods_type_id)
)
GO